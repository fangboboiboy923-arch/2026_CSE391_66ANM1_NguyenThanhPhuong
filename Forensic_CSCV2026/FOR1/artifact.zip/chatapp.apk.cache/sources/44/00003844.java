package com.example.chatapp;

import androidx.compose.ui.tooling.preview.AndroidUiModes;
import kotlin.Metadata;

/* compiled from: MainActivity.kt */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/example/chatapp/Constants;", "", "<init>", "()V", "SECRET_MESSAGE", "", "ORDER_XOR", "", "NONCE_HEX", "SELECT_MOD", "PREFS_NAME", "SALT_KEY", "app"}, k = 1, mv = {2, 2, 0}, xi = AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class Constants {
    public static final int $stable = 0;
    public static final Constants INSTANCE = new Constants();
    public static final String NONCE_HEX = "706eeff3706eeff3706eeff3706eeff3";
    public static final int ORDER_XOR = 931071618;
    public static final String PREFS_NAME = "chat_prefs";
    public static final String SALT_KEY = "device_salt";
    public static final String SECRET_MESSAGE = "sqlite3_forensics_2026";
    public static final int SELECT_MOD = 3;

    private Constants() {
    }
}